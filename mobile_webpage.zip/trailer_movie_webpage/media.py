import webbrowser

class Movie():
    def __init__(self ,movie_title, movie_storyline, poster_image,
                 trailer_youtube):
        self.title=movie_title
        self.storyline=movie_storyline
        self.poster_image_url=poster_image
        self.trailer_youtube_url=trailer_youtube
# It helps in getting values from all the movie details access all the values with the help of this.


    def show_trailer(self):
        webbrowser.open(self.trailer_youtube_url)

# it help in opening trailers on the web page itself.
        
